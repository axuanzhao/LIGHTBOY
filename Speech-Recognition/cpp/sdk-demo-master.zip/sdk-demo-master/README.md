# sdk-demo
百度AI平台RESTful API SDK调用的示例

## 百度AI平台SDK下载地址
[百度AI平台SDK下载地址](http://ai.baidu.com/sdk)

## 百度AI平台文档地址
[百度AI平台文档地址](http://ai.baidu.com/docs#/Begin/top)

