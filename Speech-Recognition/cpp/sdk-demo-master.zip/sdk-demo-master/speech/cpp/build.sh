g++ -o main main.cpp -std=c++11 -lcurl -ljsoncpp -lcrypto && ./main 
